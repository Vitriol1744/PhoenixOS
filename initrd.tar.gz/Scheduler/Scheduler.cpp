/*
 * Created by vitriol1744 on 30.11.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "Scheduler.hpp"

#include "BootInfo.hpp"
#include "Common.hpp"

#include "Arch/x86/Drivers/Time/LAPIC.hpp"
#include "Arch/x86/IDT.hpp"

#include "Memory/PhysicalMemoryManager.hpp"
#include "Scheduler/Spinlock.hpp"

#define PAGE_SIZE PhysicalMemoryManager::GetPageSize()

static Vector<Process*>  processQueue  = {};
static Process*          kernelProcess    = nullptr;
static Spinlock          lock         = {};
inline static constexpr const uint64_t defaultTimePeriod = 1000;

namespace Scheduler
{
    static ProcessID GetUniquePID()
    {
        static ProcessID pid = 0;
        return pid++;
    }
    static ThreadID GetUniqueTID()
    {
        static ThreadID tid = 0;

        return tid++;
    }

    static void          SwitchContext(CPUContext* context)
    {
        __asm__ volatile(
            "mov %0, %%rsp\n"
            "pop %%rax\n"
            "pop %%rbx\n"
            "pop %%rcx\n"
            "pop %%rdx\n"
            "pop %%rsi\n"
            "pop %%rdi\n"
            "pop %%rbp\n"
            "pop %%r8\n"
            "pop %%r9\n"
            "pop %%r10\n"
            "pop %%r11\n"
            "pop %%r12\n"
            "pop %%r13\n"
            "pop %%r14\n"
            "pop %%r15\n"

            "add $0x10, %%rsp\n"
            "swapgs\n"
            "sti\n"
            "iretq" : : "r"(context));
    }

    bool panicState = false;
    void Shutdown()
    {
        panicState = true;
    }

    void Schedule(CPUContext* context)
    {
        if (panicState) halt(context);
        //TODO: Implement some idle task when no threads are available for running
        lock.Lock();
        CPU*     cpu = CPU::GetCurrent();
        Process*  nextProcess;
        Thread*   nextThread;

//        LogInfo("cpu: %d", CPU::GetCurrentID());
        if (cpu->runningThread)
        {
            auto lastThread = cpu->runningThread;
            auto lastProcess = lastThread->process;

            lastThread->context = *context;
            lastThread->state = ThreadState::eIdle;
            processQueue.PushBack(lastProcess);
            lastProcess->threads.PushBack(lastThread);
            cpu->runningThread = nullptr;
        }

        if (processQueue.GetSize() == 0 || processQueue[0]->threads.GetSize() == 0)
        {
//            LogInfo("Empty queue");
//            if (processQueue.GetSize() == 0) LogInfo("pQueue");
            lock.Unlock();
            LAPIC::SendEOI();
            LAPIC::OneShot(defaultTimePeriod, Schedule);
            return;
        }
//        LogInfo("notempty: %d", processQueue.GetSize());
        nextProcess = processQueue[0];
        nextThread = nextProcess->threads[0];
        if (nextThread == nullptr || nextThread->state != ThreadState::eIdle)
        {
            lock.Unlock();
            LAPIC::SendEOI();
            LAPIC::OneShot(defaultTimePeriod, Schedule);
            return;
        }
        cpu->runningThread = nextThread;
        processQueue.PopFront();
        nextProcess->threads.PopFront();
        nextThread->state = ThreadState::eRunning;

        lock.Unlock();
        LAPIC::SendEOI();
        LAPIC::OneShot(defaultTimePeriod, Schedule);
        SwitchContext(&nextThread->context);
    }

    void Initialize()
    {
        kernelProcess = CreateProcess(VirtualMemoryManager::GetKernelPageMap());
        LogInfo("Scheduler: Kernel process created with pid %u", kernelProcess->pid);

        LogInfo("Scheduler: Initialized");
        LAPIC::OneShot(defaultTimePeriod, Schedule);
    }

    __attribute__((noreturn)) void Await() { NotImplemented(); }
    __attribute__((noreturn)) void Yield()
    {
        __asm__ volatile("sti");
        LAPIC::OneShot(defaultTimePeriod, Schedule);
        for (;;) __asm__ volatile("hlt");
    }

    Process* CreateProcess(PageMap& pageMap)
    {
        auto process = new Process;
        process->pid     = GetUniquePID();
        process->pageMap = pageMap;
        if (!pageMap.Exists()) LogError("Invalid PageMap!");

        lock.Lock();
        processQueue.PushBack(process);
        lock.Unlock();
        return process;
    }

    Thread* CreateThread(Process* process, uintptr_t rip, uint16_t cs, uint16_t ds)
    {
        if (process->pid == -1) return nullptr;

        const uintptr_t stack
            = (uintptr_t)PhysicalMemoryManager::CallocatePages(1) + PAGE_SIZE;

        auto thread          = new Thread;
        thread->process         = process;
        thread->tid             = GetUniqueTID();
        thread->state           = ThreadState::eIdle;
        thread->kernelStack     = stack + HIGHER_HALF_OFFSET;
        thread->kernelStackSize = PAGE_SIZE;
        thread->context.rip     = rip;
        thread->context.rsp     = thread->kernelStack;
        thread->context.cs      = cs;
        thread->context.ss      = ds;
        thread->context.rflags = 0x202;

        lock.Lock();
        process->threads.PushBack(thread);
        lock.Unlock();

        return thread;
    }
    Thread*  CreateKernelThread(Process* process, uintptr_t rip)
    {
        return CreateThread(process, rip, KERNEL_CODE_SELECTOR, KERNEL_DATA_SELECTOR);
    }
    Thread*  CreateUserThread(Process* process, uintptr_t rip)
    {
        return CreateThread(process, rip, USERLAND_CODE_SELECTOR, USERLAND_DATA_SELECTOR);
    }

    Process* GetKernelProcess() { return kernelProcess; }
} // namespace Scheduler