/*
 * Created by vitriol1744 on 23.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Memory/PhysicalMemoryManager.hpp"
#include "Scheduler/Spinlock.hpp"
#include "Utility/KLibC.hpp"
#include "Utility/Math.hpp"

class SlabAllocatorBase
{
  public:
    virtual void Free(void* ptr) = 0;
};

struct SlabHeader
{
    SlabAllocatorBase* slab;
};

template <uint64_t Bytes>
class SlabAllocator : public SlabAllocatorBase, Spinlock
{
  public:
    SlabAllocator() = default;
    void Initialize()
    {
        LogTrace("Allocating new page...");
        firstFree = (uintptr_t)PhysicalMemoryManager::CallocatePages(1)
                  + BootInfo::GetHHDMOffset();

        auto available
            = 0x1000 - Math::AlignUp(sizeof(SlabHeader), allocationSize);
        auto slabPointer  = reinterpret_cast<SlabHeader*>(firstFree);
        slabPointer->slab = this;
        firstFree += Math::AlignUp(sizeof(SlabHeader), allocationSize);

        auto array = reinterpret_cast<uint64_t*>(firstFree);
        auto max   = available / allocationSize - 1;
        auto fact  = allocationSize / 8;
        for (size_t i = 0; i < max; i++)
            array[i * fact]
                = reinterpret_cast<uint64_t>(&array[(i + 1) * fact]);
        array[max * fact] = 0;
    }

    template <typename T>
    T Allocate()
    {
        AutomaticLock(*this);
        if (!firstFree) Initialize();

        auto oldFree = reinterpret_cast<uint64_t*>(firstFree);
        firstFree    = oldFree[0];
        memset(oldFree, 0, allocationSize);

        return oldFree;
    }
    void Free(void* memory) override
    {
        if (!memory) return;
        AutomaticLock(*this);

        auto newHead = static_cast<uint64_t*>(memory);
        newHead[0]   = firstFree;
        firstFree    = reinterpret_cast<uintptr_t>(newHead);
    }

  private:
    uintptr_t firstFree      = 0;
    size_t    allocationSize = Bytes;
};
