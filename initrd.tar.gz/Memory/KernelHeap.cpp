/*
 * Created by vitriol1744 on 28.11.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "KernelHeap.hpp"

#include "BootInfo.hpp"
#include "Common.hpp"

#include "Memory/PhysicalMemoryManager.hpp"
#include "Memory/SlabAllocator.hpp"

#include "Utility/KLibC.hpp"

SlabAllocator<8>    allocator8    = {};
SlabAllocator<16>   allocator16   = {};
SlabAllocator<32>   allocator32   = {};
SlabAllocator<64>   allocator64   = {};
SlabAllocator<128>  allocator128  = {};
SlabAllocator<256>  allocator256  = {};
SlabAllocator<512>  allocator512  = {};
SlabAllocator<1024> allocator1024 = {};

struct BigAllocMeta
{
    size_t pages;
    size_t size;
};
void* malloc(size_t size)
{
    size_t pages = Math::AlignUp(size, 4096) / 4096;
    if (size <= 8) return allocator8.Allocate<void*>();
    else if (size <= 16) return allocator16.Allocate<void*>();
    else if (size <= 32) return allocator32.Allocate<void*>();
    else if (size <= 64) return allocator64.Allocate<void*>();
    else if (size <= 128) return allocator128.Allocate<void*>();
    else if (size <= 256) return allocator256.Allocate<void*>();
    else if (size <= 512) return allocator512.Allocate<void*>();
    else if (size <= 1024) return allocator1024.Allocate<void*>();
    else
    {
        void* ptr = (uint8_t*)(PhysicalMemoryManager::CallocatePages(pages + 1))
                  + BootInfo::GetHHDMOffset();

        auto metadata   = reinterpret_cast<BigAllocMeta*>(ptr);
        metadata->pages = pages;
        metadata->size  = size;
        return reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(ptr)
                                       + 0x1000);
    }
}
void free(void* ptr)
{
    if (!ptr) return;

    if ((reinterpret_cast<uintptr_t>(ptr) & 0xfff) == 0)
    {
        auto metadata = reinterpret_cast<BigAllocMeta*>(
            reinterpret_cast<uintptr_t>(ptr) - 0x1000);
        PhysicalMemoryManager::FreePages(
            (uint8_t*)(metadata)-BootInfo::GetHHDMOffset(),
            metadata->pages + 1);
    }
    else
        reinterpret_cast<SlabHeader*>(reinterpret_cast<uintptr_t>(ptr) & ~0xfff)
            ->slab->Free(ptr);
}

void* operator new(size_t size) { return malloc(size); }
void* operator new[](size_t size) { return malloc(size); }
void  operator delete(void* ptr) noexcept { free(ptr); }
void  operator delete[](void* ptr) noexcept { free(ptr); }
void  operator delete(void* ptr, size_t size) noexcept { free(ptr); }

namespace KernelHeap
{
    void Initialize()
    {
        allocator8.Initialize();
        allocator16.Initialize();
        allocator32.Initialize();
        allocator64.Initialize();
        allocator128.Initialize();
        allocator256.Initialize();
        allocator512.Initialize();
        allocator1024.Initialize();
    }

    void* Allocate(size_t bytes) { return malloc(bytes); }
    void* Callocate(size_t bytes)
    {
        void* ret = Allocate(bytes);
        memset(ret, 0, bytes);

        return ret;
    }
    void Free(void* memory) { return free(memory); }
} // namespace KernelHeap