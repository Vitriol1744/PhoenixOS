/*
 * Created by vitriol1744 on 25.11.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Drivers/Terminal.hpp"

#include "Arch/Interrupts/InterruptHandler.hpp"
#include "Utility/Logger.hpp"

#define BIT(n)    (1ull << n)
#define PH_UNUSED [[maybe_unused]]

#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>

using symbol                   = void*[];

using InterruptHandlerFunction = void (*)(struct CPUContext*);
namespace IDT
{
    void RegisterInterruptHandler(InterruptHandler* handler, uint8_t dpl);
}
namespace Scheduler
{
    void Shutdown();
}

[[noreturn]] inline static void halt(struct CPUContext* = nullptr)
{
    while (true) __asm__ volatile("cli; hlt");
}

#include "Utility/Stacktrace.hpp"

#define ENABLE_CLEAR_SCREEN_ON_PANIC false
[[noreturn]] inline static void panic(const char* msg, ...)
{
    // TODO: Stop all cpus
#if ENABLE_CLEAR_SCREEN_ON_PANIC != false
    Terminal::ClearScreen(0x0000ff);
#endif
    Scheduler::Shutdown();
    //    IDT::RegisterInterruptHandler(0x20, halt, 0);
    LogFatal("Kernel Panic!\n");

    va_list args;
    va_start(args, msg);
    Logger::Logv(LogLevel::eFatal, msg, args);
    va_end(args);
    LogFatal("\n");

    Stacktrace::Print(10);
    halt(nullptr);
}

#define Assert(expr) AssertMsg(expr, #expr)
#define AssertMsg(expr, msg)                                                   \
    !(expr) ? panic("Assertion Failed: %s, In File: %s, At Line: %d", msg,     \
                    __FILE__, __LINE__)                                        \
            : (void)0;
#define NotImplemented() AssertMsg(false, "Function is not implemented!")
