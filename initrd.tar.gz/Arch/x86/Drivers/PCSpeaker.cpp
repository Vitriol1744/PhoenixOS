/*
 * Created by vitriol1744 on 03.01.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "PCSpeaker.hpp"

#include "Arch/x86/Drivers/Time/PIT.hpp"
#include "Arch/x86/IO.hpp"

namespace PCSpeaker
{
    void PlaySound(uint32_t frequency)
    {

        IO::Out<byte>(0x43, 0x42 | 0x30 | 0x06);
        uint16_t timer_reload = PIT_BASE_FREQUENCY / frequency;

        IO::Out<byte>(0x42, timer_reload);
        IO::Out<byte>(0x42, timer_reload >> 8);

        IO::Out<byte>(0x61, IO::In<byte>(0x61) | 3);
    }
    void Stop() { IO::Out<byte>(0x61, IO::In<byte>(0x61) & ~3); }
    void Beep()
    {
        PlaySound(1000);
        IO::Delay(1000);
        Stop();
    }
} // namespace PCSpeaker