/*
 * Created by vitriol1744 on 07.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "ACPI.hpp"

#include "BootInfo.hpp"
#include "Common.hpp"

#include "Utility/KLibC.hpp"

namespace ACPI
{
#pragma pack(push, 1)
    struct RSDP
    {
        char     signature[8];
        uint8_t  checksum;
        char     oemID[6];
        uint8_t  revision;
        uint32_t rsdtAddress;
        uint32_t length;
        uint64_t xsdtAddress;
        uint8_t  extendedChecksum;
        uint8_t  reserved[3];
    };
    struct RSDT
    {
        SDTHeader header;
        char      sdts[];
    };
#pragma pack(pop)

    static bool  xsdt = false;
    static RSDT* rsdt;

    static bool  ValidateChecksum(SDTHeader* header)
    {
        uint32_t checksum = 0;
        for (uint32_t i = 0; i < header->length; i++)
            checksum += ((char*)header)[i];

        return checksum;
    }
    static uintptr_t GetTablePointer(uint8_t index)
    {
        if (xsdt)
        {
            const uint64_t* ptr = (uint64_t*)rsdt->sdts;

            return ptr[index] + BootInfo::GetHHDMOffset();
        }

        const uint32_t* ptr = (uint32_t*)rsdt->sdts;
        return (uint64_t)ptr[index] + (uint64_t)BootInfo::GetHHDMOffset();
    }
    static void PrintACPITables()
    {
        const size_t entryCount = (rsdt->header.length - sizeof(SDTHeader)) / 4;
        LogInfo("Present ACPI tables(%lld): ", entryCount);
        char acpiSignature[5];
        acpiSignature[4] = 0;
        for (size_t i = 0; i < entryCount; i++)
        {
            SDTHeader* header
                = reinterpret_cast<SDTHeader*>(GetTablePointer(i));
            if (!header || !((char*)header->signature)) continue;
            memcpy(acpiSignature, header->signature, 4);
            LogInfo("  -%s", acpiSignature);
        }
    }

    // TODO: FADT and ACPI GetMode
    void Initialize()
    {
        RSDP* rsdp = reinterpret_cast<RSDP*>(BootInfo::GetRSDPAddress());
        xsdt       = rsdp->revision == 2 && rsdp->xsdtAddress != 0;

        uint64_t rsdtPointer = xsdt ? rsdp->xsdtAddress : rsdp->rsdtAddress;
        rsdt = reinterpret_cast<RSDT*>(rsdtPointer + BootInfo::GetHHDMOffset());
        Assert(rsdt != nullptr);
        PrintACPITables();
    }
    SDTHeader* GetTable(const char* signature, size_t index)
    {
        Assert(signature != nullptr);

        size_t       count      = 0;
        const size_t entryCount = (rsdt->header.length - sizeof(SDTHeader)) / 4;
        for (size_t i = 0; i < entryCount; ++i)
        {
            SDTHeader* header
                = reinterpret_cast<SDTHeader*>(GetTablePointer(i));

            if (!header || !((char*)header->signature)) continue;
            if (!ValidateChecksum(header)) continue;

            if (!strncmp(header->signature, signature, 4)) return header;
        }

        LogWarn("Failed to find %s table", signature);
        return nullptr;
    }
} // namespace ACPI