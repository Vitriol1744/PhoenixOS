/*
 * Created by vitriol1744 on 21.03.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "VirtualFileSystem/VirtualFileSystem.hpp"

#include <cstdint>
#include <details/string_view>
#include <mutex>

enum class INodeType
{
    eRegular         = 0,
    eHardLink        = 1,
    eSymlink         = 2,
    eCharacterDevice = 3,
    eBlockDevice     = 4,
    eDirectory       = 5,
};

class INode
{
  public:
    std::mutex                                   lock;

    Filesystem*                                  filesystem;
    //    VirtualFileSystem::resource*                 res;
    stat_t                                       stat;

    std::unordered_map<std::string_view, INode*> children;

    std::string                                  name;
    std::string                                  target;

    INode*                                       mountgate;
    INode*                                       parent;

    INode(std::string_view name, mode_t mode)
        : name(name)
    {
        stat.st_size    = 0;
        stat.st_blocks  = 0;
        stat.st_blksize = 512;
        stat.st_mode    = mode;
        stat.st_nlink   = 1;
    }
    INode(std::string_view name, INode* parent, Filesystem* fs, mode_t mode)
        : filesystem(fs)
        , name(name)
        , parent(parent)
    {
        stat.st_size    = 0;
        stat.st_blocks  = 0;
        stat.st_blksize = 512;
        stat.st_dev     = fs->dev_id;
        stat.st_ino     = fs->inodes++;
        stat.st_mode    = mode;
        stat.st_nlink   = 1;
    }

    virtual ~INode() {}

    INode*          Reduce(bool symlinks, bool automount = true);
    std::string     GetPath();

    types           GetType();
    mode_t          GetMode();

    bool            IsEmpty();

    virtual void    InsertChild(INode* node, std::string_view name)        = 0;
    virtual ssize_t Read(void* buffer, ssize_t offset, size_t bytes)       = 0;
    //    {
    //        return 0;
    //    }
    virtual ssize_t Write(const void* buffer, size_t offset, size_t bytes) = 0;
    //    {
    //        return 0;
    //    }

  private:
    INodeType type;

    INode*    InternalReduce(bool symlinks, bool automount, size_t cnt);
};