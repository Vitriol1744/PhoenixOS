/*
 * Created by vitriol1744 on 19.06.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "TmpFs.hpp"
#include "Arch/x86/CPU.hpp"
#include "Scheduler/Thread.hpp"
#include "TmpFsINode.hpp"
#include "Utility/Math.hpp"
#include "VirtualFileSystem/DevTmpFs/DevTmpFs.hpp"
#include "VirtualFileSystem/INode.hpp"

#define hhdm_offset BootInfo::GetHHDMOffset()

constexpr inline auto div_roundup(auto n, auto a)
{
    return Math::AlignDown(n + a - 1, a) / a;
}

#define PAGE_SIZE 0x1000
static constexpr size_t default_size = PAGE_SIZE;

void                    TmpFs::parse_data()
{
    max_size   = PhysicalMemoryManager::GetTotalMemory() / 2;
    max_inodes = PhysicalMemoryManager::GetTotalMemory() / PAGE_SIZE / 2;
}

TmpFs::TmpFs()
    : Filesystem("TmpFs")
    , max_inodes(0)
    , max_size(0)
    , current_size(0)
    , root_mode(01777)
    , root_gid(0)
    , root_uid(0)
{

    //        root           = new TmpFsINode(name, nullptr, this, 0777 |
    //        s_ifreg,
    //                                        new resource(this, 0777 |
    //                                        s_ifreg));
}

bool   TmpFs::Sync(VirtualFileSystem::resource* res) { return true; }

INode* TmpFs::CreateNode(INode* parent, std::string_view name, mode_t mode)
{
    if (inodes >= max_inodes
        || (mode2type(mode) == s_ifreg
            && current_size + default_size > max_size))
    {
        errno = ENOSPC;
        return nullptr;
    }

    return new TmpFsINode(name, parent, this, mode);
}

INode* TmpFs::Symlink(INode* parent, std::string_view name,
                      std::string_view target)
{
    if (inodes >= max_inodes)
    {
        errno = ENOSPC;
        return nullptr;
    }

    auto node    = new TmpFsINode(name, parent, this, 0777 | s_iflnk);
    node->target = target;
    return node;
}

INode* TmpFs::Link(INode* parent, std::string_view name, INode* old_node)
{
    if (old_node->GetType() == s_ifdir)
    {
        errno = EISDIR;
        return nullptr;
    }

    return new TmpFsINode(name, parent, this, old_node->stat.mode());
}

bool   TmpFs::Unlink(INode*) { return true; }

INode* TmpFs::mknod(INode* parent, std::string_view name, dev_t dev,
                    mode_t mode)
{
    return nullptr;
}

void TmpFs::Initialize() {}