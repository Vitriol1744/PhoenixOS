/*
 * Created by vitriol1744 on 28.03.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Utility/KLibC.hpp"
#include "Utility/Logger.hpp"
#include "VirtualFileSystem/INode.hpp"

#include <unordered_map>

class TmpFsINode : public INode
{
  public:
    TmpFsINode(std::string_view name, mode_t mode)
        : INode(name, mode)
    {
        capacity = 128;
        data     = new uint8_t[capacity];
    }
    TmpFsINode(std::string_view name, INode* parent, Filesystem* fs,
               mode_t mode)
        : INode(name, parent, fs, mode)
    {
        capacity        = 128;
        data            = new uint8_t[capacity];
        stat.st_size    = 0;
        stat.st_blocks  = 0;
        stat.st_blksize = 512;
        stat.st_dev     = fs->dev_id;
        stat.st_ino     = fs->inodes++;
        stat.st_mode    = mode;
        stat.st_nlink   = 1;
    }

    ~TmpFsINode()
    {
        if (capacity > 0) delete data;
    }

    virtual void InsertChild(INode* node, std::string_view name)
    {
        std::unique_lock guard(lock);
        children[name] = node;
    }
    virtual ssize_t Read(void* buffer, ssize_t offset, size_t bytes);
    virtual ssize_t Write(const void* buffer, size_t offset, size_t bytes);

  private:
    uint8_t* data     = nullptr;
    size_t   size     = 0;
    size_t   capacity = 0;
    stat_t   stat{};
};