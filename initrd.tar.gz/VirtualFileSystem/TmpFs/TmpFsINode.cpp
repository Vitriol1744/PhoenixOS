/*
 * Created by vitriol1744 on 28.03.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "TmpFsINode.hpp"

#include "Utility/Math.hpp"
#include "VirtualFileSystem/TmpFs/TmpFs.hpp"

constexpr inline auto div_roundup(auto n, auto a)
{
    return Math::AlignDown(n + a - 1, a) / a;
}

ssize_t TmpFsINode::Read(void* buffer, ssize_t offset, size_t bytes)
{
    std::unique_lock guard(lock);

    auto             real_count = bytes;
    if (ssize_t(offset + bytes) >= stat.st_size)
        real_count = bytes - ((offset + bytes) - stat.st_size);

    memcpy(buffer, reinterpret_cast<uint8_t*>(data) + offset, real_count);
    return real_count;
}
ssize_t TmpFsINode::Write(const void* buffer, size_t offset, size_t bytes)
{
    std::unique_lock guard(lock);

    if (offset + bytes > capacity)
    {
        size_t newCapacity = capacity;
        while (offset + bytes >= newCapacity) newCapacity *= 2;

        auto tfs = reinterpret_cast<TmpFs*>(filesystem);
        if (tfs->current_size + (newCapacity - capacity) > tfs->max_size)
        {
            errno = ENOSPC;
            return -1;
        }

        data     = static_cast<uint8_t*>(realloc(data, newCapacity));
        capacity = newCapacity;
    }

    memcpy(data + offset, buffer, bytes);

    if (ssize_t(offset + bytes) >= stat.st_size)
    {
        stat.st_size   = offset + bytes;
        stat.st_blocks = div_roundup(offset + bytes, stat.st_blksize);
    }

    return bytes;
}
