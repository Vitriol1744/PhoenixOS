/*
 * Created by vitriol1744 on 19.06.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "VirtualFileSystem/INode.hpp"
#include "VirtualFileSystem/TmpFs/TmpFsINode.hpp"
#include "VirtualFileSystem/VirtualFileSystem.hpp"

struct TmpFs : public Filesystem
{
    size_t max_inodes   = 0;
    size_t max_size     = 0;

    size_t current_size = 0;

    mode_t root_mode    = 0;
    gid_t  root_gid     = 0;
    uid_t  root_uid     = 0;

    void   parse_data();

    TmpFs();

    virtual bool Populate(INode* node, std::string_view single = "") override
    {
        return false;
    }
    bool   Sync(VirtualFileSystem::resource* res) override;

    INode* CreateNode(INode* parent, std::string_view name,
                      mode_t mode) override;
    INode* Symlink(INode* parent, std::string_view name,
                   std::string_view target) override;
    INode* Link(INode* parent, std::string_view name, INode* old_node) override;
    bool   Unlink(INode* node) override;

    INode* mknod(INode* parent, std::string_view name, dev_t dev,
                 mode_t mode) override;
    static void Initialize();
};
