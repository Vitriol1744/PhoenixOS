/*
 * Created by vitriol1744 on 19.06.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "Initrd.hpp"

#include "Memory/PhysicalMemoryManager.hpp"
#include "Memory/VirtualMemoryManager.hpp"
#include "Ustar.hpp"
#include "Utility/Math.hpp"

#include "BootInfo.hpp"

namespace Initrd
{
    void Initialize()
    {
        auto initrd = findModule("initrd");
        if (!initrd)
        {
            LogError("Could not find initrd module!");
            return;
        }

        auto address
            = ToHigherHalfAddress(reinterpret_cast<uintptr_t>(initrd->address));

        if (Ustar::Validate(address))
        {
            LogTrace("Initrd: Trying to load USTAR archive...");
            Ustar::Load(address);
        }
        else LogError("Initrd: Unknown archive format!");

#define PAGE_SIZE PhysicalMemoryManager::GetPageSize()
        size_t pageCount = (Math::AlignUp(initrd->size, 512) + 512) / PAGE_SIZE;
        PhysicalMemoryManager::FreePages(
            reinterpret_cast<void*>(FromHigherHalfAddress(address)), pageCount);
        LogInfo("everything done");
    }
} // namespace Initrd