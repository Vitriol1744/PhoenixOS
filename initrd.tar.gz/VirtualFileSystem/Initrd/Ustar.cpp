/*
 * Created by vitriol1744 on 19.06.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "Ustar.hpp"

#include "Utility/Math.hpp"
#include "VirtualFileSystem/DevTmpFs/DevTmpFs.hpp"
#include "VirtualFileSystem/INode.hpp"
#include "VirtualFileSystem/VirtualFileSystem.hpp"

template <typename T>
inline static T parseOctNumber(const char* str, size_t len)
    requires std::is_trivial_v<T>
{
    T value = 0;
    while (*str && len > 0)
    {
        value = value * 8 + (*str++ - '0');
        --len;
    }

    return value;
}

namespace Ustar
{
    bool Validate(uintptr_t address)
    {
        return strncmp(reinterpret_cast<FileHeader*>(address)->signature, MAGIC,
                       MAGIC_LENGTH)
            == 0;
    }

    void Load(uintptr_t address)
    {
        auto current = reinterpret_cast<FileHeader*>(address);
        auto getNextFile
            = [](FileHeader* current, size_t fileSize) -> FileHeader*
        {
            uintptr_t nextFile = reinterpret_cast<uintptr_t>(current) + 512
                               + Math::AlignUp(fileSize, 512);

            return reinterpret_cast<FileHeader*>(nextFile);
        };

        static int32_t maxFiles = 13;

        while (strncmp(current->signature, MAGIC, 6) == 0)
        {
            std::string_view filename(current->filename);
            std::string_view linkName(current->linkName);
            LogInfo("Filename: %s", filename.data());

            mode_t mode
                = parseOctNumber<mode_t>(current->mode, sizeof(current->mode));
            size_t size = parseOctNumber<size_t>(current->fileSize,
                                                 sizeof(current->fileSize));

            if (filename == "./" || filename == ".")
            {
                LogInfo("continue");
                current = getNextFile(current, size);
                continue;
            }

            LogInfo("switch");
            INode* node = nullptr;
            switch (current->type)
            {
                case FILE_TYPE_NORMAL:
                case FILE_TYPE_NORMAL_:
                    LogInfo("Creating node %s...", filename.data());
                    node = VirtualFileSystem::CreateNode(nullptr, filename,
                                                         mode | s_ifreg);
                    LogInfo("file created");

                    if (!node)
                    {
                        LogError(
                            "USTAR: Failed to create regular file!, path: "
                            "'%s'",
                            filename.data());
                        LogInfo("file created");
                        break;
                    }
                    else if (node->Write(
                                 reinterpret_cast<uint8_t*>(
                                     reinterpret_cast<uintptr_t>(current)
                                     + 512),
                                 0, size)
                             != ssize_t(size))
                        LogError(
                            "USTAR: Could not write to regular file! path: "
                            "'%s'",
                            filename.data());
                    break;
                case FILE_TYPE_HARD_LINK:
                    //                    node =
                    //                    VirtualFileSystem::Link(nullptr,
                    //                    filename, nullptr,
                    //                                                   linkName);
                    //                    if (!node)
                    LogError("USTAR: Failed to create hardlink: '%s' -> '%s'",
                             filename.data(), linkName.data());
                    break;
                case FILE_TYPE_SYMLINK:
                    //                    node =
                    //                    VirtualFileSystem::Symlink(nullptr,
                    //                    filename,
                    //                                                      linkName);
                    //                    if (!node)
                    LogError("USTAR: Failed to create Symlink: '%s' -> '%s'",
                             filename.data(), linkName.data());
                    break;
                case FILE_TYPE_CHARACTER_DEVICE:
                {
                    uint32_t deviceMajor = parseOctNumber<uint32_t>(
                        current->deviceMajor, sizeof(current->deviceMajor));
                    uint32_t deviceMinor = parseOctNumber<uint32_t>(
                        current->deviceMinor, sizeof(current->deviceMinor));
                    LogError(
                        "USTAR: Failed to create character device: '%s' "
                        "(%d:%d)",
                        filename.data(), deviceMajor, deviceMinor);
                    NotImplemented();
                }
                break;
                case FILE_TYPE_BLOCK_DEVICE: NotImplemented();
                case FILE_TYPE_DIRECTORY:
                    LogInfo("Creating node %s...", filename.data());
                    node = VirtualFileSystem::CreateNode(nullptr, filename,
                                                         mode | s_ifdir);
                    if (node == nullptr)
                        LogError(
                            "USTAR: Failed to create a directory! path: '%s'",
                            filename.data());
                    break;
                case FILE_TYPE_FIFO: NotImplemented() break;
                default: break;
            }

            //            time_t mtime = parseOctNumber<time_t>(current->mtime,
            //                                                  sizeof(current->mtime));
            //            if (node) node->stat.st_mtim = timespec(mtime, 0);
            LogInfo("next");
            current = getNextFile(current, size);
        }
    }
} // namespace Ustar