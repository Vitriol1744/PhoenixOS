/*
 * Created by vitriol1744 on 21.03.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Utility/types.hpp"
#include <atomic>
#include <cerrno>
#include <cstdlib>
#include <mutex>
#include <optional>
#include <string>

class INode;
namespace VirtualFileSystem
{
    struct resource;
}
struct Filesystem
{
    INode*             mounted_on = nullptr;
    void*              mountdata  = nullptr;
    INode*             root       = nullptr;

    std::atomic<ino_t> inodes     = 0;
    dev_t              dev_id     = 0;
    std::mutex         lock;

    std::string        name;

    Filesystem(const std::string& name)
        : mounted_on(nullptr)
        , mountdata(nullptr)
        , name(name)
    {
    }

    virtual void   parse_data() {}

    virtual bool   Populate(INode* node, std::string_view single = "") = 0;
    virtual bool   Sync(VirtualFileSystem::resource* res)              = 0;

    virtual INode* CreateNode(INode* parent, std::string_view name, mode_t mode)
        = 0;
    virtual INode* Symlink(INode* parent, std::string_view name,
                           std::string_view target)
        = 0;

    virtual INode* Link(INode* parent, std::string_view name, INode* old_node)
        = 0;
    virtual bool   Unlink(INode* node) = 0;

    virtual INode* mknod(INode* parent, std::string_view name, dev_t dev,
                         mode_t mode)
        = 0;
};