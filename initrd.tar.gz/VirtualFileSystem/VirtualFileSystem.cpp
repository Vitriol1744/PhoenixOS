/*
 * Created by vitriol1744 on 19.06.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "VirtualFileSystem.hpp"

#include "Arch/x86/CPU.hpp"
#include "VirtualFileSystem/INode.hpp"
#include "VirtualFileSystem/TmpFs/TmpFs.hpp"

#include <unordered_map>

namespace VirtualFileSystem
{
    static INode*      rootINode = nullptr;
    static std::mutex  lock;

    INode*             GetRootINode() { return rootINode; }

    static Filesystem* CreateFilesystem(std::string_view name)
    {
        Filesystem* fs = nullptr;
        if (name == "TmpFs") fs = new TmpFs();

        return fs;
    }
    static INode* InternalMount(Filesystem* fs, INode* parent,
                                std::string_view name, void* data)
    {
        fs->mountdata = data ? reinterpret_cast<void*>(
                            strdup(static_cast<const char*>(data)))
                             : nullptr;

        fs->parse_data();

        fs->root = fs->CreateNode(parent, name, 01777 | s_ifdir);
        return fs->root;
    }

    void RecursiveDelete(INode* node)
    {
        if (!node) return;

        if (node->GetType() == s_ifdir)
            for (auto [name, child] : node->children) RecursiveDelete(child);

        delete node;
    }

    std::tuple<INode*, INode*, std::string>
    ResolvePath(INode* parent, std::string_view path, bool automount)
    {
        if (!parent || Path::IsAbsolute(path)) parent = GetRootINode();

        auto currentNode = parent->Reduce(false);

        if (path == "/" || path.empty()) return {currentNode, currentNode, "/"};

        auto getParent = [&currentNode]
        {
            if (currentNode == GetRootINode()->Reduce(false))
                return currentNode;
            else if (currentNode == currentNode->filesystem->root)
                return currentNode->filesystem->mounted_on->parent;

            return currentNode->parent;
        };

        auto segments = Path::GetSegments(path);
        for (auto [segment, type, isLast] : segments)
        {
            if (type != CWK_NORMAL)
            {
                if (type == CWK_BACK) currentNode = getParent();

                if (isLast)
                    return {getParent(), currentNode, currentNode->name};

                continue;
            }

            if (currentNode->children.contains(segment)
                || currentNode->filesystem->Populate(currentNode, segment))
            {
                auto node = currentNode->children[segment]->Reduce(
                    false, !isLast || automount);

                if (isLast) return {currentNode, node, node->name};

                currentNode = node;

                if (currentNode->GetType() == s_iflnk)
                {
                    currentNode = currentNode->Reduce(true);
                    if (currentNode == nullptr) return {nullptr, nullptr, ""};
                }

                if (currentNode->GetType() != s_ifdir)
                {
                    errno = ENOTDIR;
                    return {nullptr, nullptr, ""};
                }

                continue;
            }

            errno = ENOENT;
            if (isLast)
                return {
                    currentNode, nullptr, {segment.data(), segment.length()}};

            break;
        }

        errno = ENOENT;
        return {nullptr, nullptr, ""};
    }

    bool MountRoot(std::string_view filesystemName)
    {
        auto fs = CreateFilesystem(filesystemName);
        if (!fs) return false;
        if (rootINode)
        {
            LogError("VFS: Root already mounted!");
            return false;
        }

        rootINode = InternalMount(fs, nullptr, "/", nullptr);

        return rootINode != nullptr;
    }
    // TODO: flags
    bool Mount(INode* parent, PathView source, PathView target,
               std::string_view fs_name, int flags, void* data)
    {
        std::unique_lock guard(lock);

        Filesystem*      fs = CreateFilesystem(fs_name);
        if (fs == nullptr)
        {
            errno = ENODEV;
            return false;
        }
        INode* sourceNode              = nullptr;

        auto [nparent, node, basename] = ResolvePath(parent, target);
        bool isRoot                    = (node == GetRootINode());

        if (!node) return false;

        if (!isRoot && node->GetType() != s_ifdir)
        {
            errno = ENOTDIR;
            return false;
        }

        auto mountgate = InternalMount(fs, parent, basename, data);
        if (!mountgate) return false;

        node->mountgate = mountgate;
        fs->mounted_on  = node;

        if (source.length() == 0)
            LogTrace("VFS: Mounted Filesystem '%s' on '%s'", fs_name.data(),
                     target.data());
        else
            LogTrace("VFS: Mounted  '%s' on '%s' with Filesystem '%s'",
                     source.data(), target.data(), fs_name.data());
        return true;
    }

    // TODO: Unmount
    bool Unmount(INode* parent, PathView path, int flags)
    {
        auto [_parent, node, name] = ResolvePath(parent, path);
        VirtualFileSystem::RecursiveDelete(node->filesystem->root);
        if (node->filesystem->mountdata) free(node->filesystem->mountdata);
        return false;
    }

    INode* CreateNode(INode* parent, PathView path, mode_t mode)
    {
        std::unique_lock guard(lock);

        auto [newNodeParent, newNode, newNodeName] = ResolvePath(parent, path);
        if (newNode)
        {
            errno = EEXIST;
            return nullptr;
        }

        if (!newNodeParent) return nullptr;

        newNode = newNodeParent->filesystem->CreateNode(newNodeParent,
                                                        newNodeName, mode);
        if (newNode) newNodeParent->InsertChild(newNode, newNode->name);
        return newNode;
    }

    INode* Symlink(INode* parent, PathView path, std::string_view target)
    {
        std::unique_lock guard(lock);

        auto [newNodeParent, newNode, newNodeName] = ResolvePath(parent, path);
        if (newNode)
        {
            errno = EEXIST;
            return nullptr;
        }

        if (!newNodeParent) return nullptr;

        newNode = newNodeParent->filesystem->Symlink(newNodeParent, newNodeName,
                                                     target);
        if (newNode) newNodeParent->InsertChild(newNode, newNode->name);
        return newNode;
    }

    INode* Link(INode* oldParent, PathView oldPath, INode* newParent,
                PathView newPath, int flags)
    {
    }

    bool Unlink(INode* parent, PathView path, int flags) {}
} // namespace VirtualFileSystem