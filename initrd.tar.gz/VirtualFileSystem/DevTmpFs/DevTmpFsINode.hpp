/*
 * Created by vitriol1744 on 21.06.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "VirtualFileSystem/INode.hpp"

class DevTmpFsINode : public INode
{
  public:
};
