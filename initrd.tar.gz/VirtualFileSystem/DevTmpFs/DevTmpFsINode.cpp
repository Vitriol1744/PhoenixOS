/*
 * Created by vitriol1744 on 21.06.2023.
 * Copyright (c) 2022-2023, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */                                                                            \
#include "DevTmpFsINode.hpp"
