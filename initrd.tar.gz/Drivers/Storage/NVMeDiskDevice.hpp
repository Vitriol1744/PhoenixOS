/*
 * Created by vitriol1744 on 20.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Common.hpp"

#include "Drivers/DiskDevice.hpp"

struct NVMeIdentifyNamespace
{
    uint64_t blockCount;
    uint64_t capabilities;
    uint64_t nuse;
    uint16_t unused1;
    uint8_t  flbas;
    uint8_t  unused2[100];
    uint32_t lbaf[16];
    uint8_t  reserved1[192];
    uint8_t  vendorSpecific[3712];
};

class NVMeDiskDevice : public DiskDevice
{
  public:
    NVMeDiskDevice() = default;
    NVMeDiskDevice(class NVMeController& controller, uint32_t namespaceID)
        : controller(&controller), namespaceID(namespaceID) {}
    bool Initialize();

    inline virtual uint64_t Write(void* buffer, uint64_t lba, uint64_t count)
    {
        return ReadWrite(buffer, lba, count, true);
    }
    inline virtual uint64_t Read(void* buffer, uint64_t lba, uint64_t count)
    {
        return ReadWrite(buffer, lba, count, false);
    }

    uint64_t GetBlockCount() const override { return blockCount; }
    uint64_t GetBlockSize() const override { return blockSize; }


    NVMeController* controller = nullptr;
    uint32_t        namespaceID = 0;
    uint64_t blockCount = 0;
    uint64_t blockSize = 0;

    uint64_t        ReadWrite(void* buffer, uint64_t lba, uint64_t count, bool write = false);
};
