/*
 * Created by vitriol1744 on 20.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "NVMeQueue.hpp"

#include "Utility/KLibC.hpp"

void NVMeQueue::Initialize(volatile NVMeSubmission* submitQueue,
                           volatile NVMeCompletion* completeQueue,
                           volatile uint32_t* submitDB,
                           volatile uint32_t* completeDB, uint16_t qid,
                           uint8_t irq, uint32_t qdepth)
{
    submit           = submitQueue;
    completion       = completeQueue;
    id               = qid;
    depth            = qdepth;
    submitDoorbell   = submitDB;
    completeDoorbell = completeDB;

    cqVector               = 0;
    sqHead                 = 0;
    tail                   = 0;
    cqHead                 = 0;
    cqPhase                = 1;
    commandID              = 0;
}

void NVMeQueue::Submit(NVMeSubmission* command)
{
    uint16_t currentTail = tail;
    memcpy((void*)&submit[tail], command, sizeof(NVMeSubmission));
    currentTail++;
    if (currentTail == depth) currentTail = 0;
    *(submitDoorbell) = currentTail;
    tail              = currentTail;
}
uint16_t NVMeQueue::SubmitWait(NVMeSubmission* command)
{
    uint16_t currentHead  = cqHead;
    uint16_t currentPhase = cqPhase;
    command->commandID    = commandID;
    Submit(command);
    uint16_t status;

    while (true)
    {
        status = completion[cqHead].status;
        if ((status & 0x1) == currentPhase) break;
    }
    status >>= 1;
    if (status)
    {
        LogError("NVMe: Error: %x", status);
        return status;
    }
    cqHead++;
    if (cqHead == depth)
    {
        cqHead  = 0;
        cqPhase = !(cqPhase);
    }
    *(completeDoorbell) = currentHead;
    return status;
}