/*
 * Created by vitriol1744 on 16.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Arch/x86/CPU.hpp"

#include "Drivers/PCI.hpp"

#include "Drivers/Storage/NVMeDiskDevice.hpp"
#include "Drivers/Storage/NVMeQueue.hpp"

#include <atomic>
#include <vector>

class NVMeController
{
  public:
    NVMeController() = default;

    struct ControllerRegister
    {
        uint64_t cap;
        uint32_t vs;
        uint32_t intms;
        uint32_t intmc;
        uint32_t cc;
        uint32_t reserved0;
        uint32_t csts;
        uint32_t nssr;
        uint32_t aqa;
        uint64_t asq;
        uint64_t acq;
    } __attribute__((packed));

    void              Initialize(PCI::Address addr);
    void              Shutdown();

    inline uint64_t   GetMaxDataTransfer() const { return maxDataTransfer; }
    inline NVMeQueue& GetAdminQueue() { return adminQueue; }
    inline NVMeQueue& GetIOQueue() { return ioQueues[CPU::GetCurrentID()]; }

  private:
    static std::atomic<uint32_t> controllerCount;
    ControllerRegister volatile* volatile cr;
    PCI::BAR                    bar0;
    uint64_t                    maxDataTransfer = 0;
    NVMeQueue                   adminQueue{};
    NVMeQueue*                  ioQueues = nullptr;
    std::vector<NVMeDiskDevice> devices;

    int                         Identify(struct ControllerInfo* id);
    void                        DetectDevices();
};