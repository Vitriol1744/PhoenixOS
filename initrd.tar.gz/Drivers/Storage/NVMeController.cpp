/*
 * Created by vitriol1744 on 18.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "NVMeController.hpp"
#include "Drivers/Storage/NVMeQueue.hpp"

#include "Arch/x86/CPU.hpp"
#include "Arch/x86/Drivers/Interrupts/PIC.hpp"
#include "Arch/x86/IO.hpp"

#include "Utility/Math.hpp"

#include <algorithm>

inline static constexpr const uint32_t NVME_CC_EN     = BIT(0);
inline static constexpr const uint32_t NVME_CC_IOSQES = (6 << 16);
inline static constexpr const uint32_t NVME_CC_IOCQES = (4 << 20);
inline static constexpr const uint32_t NVME_CSTS_RDY  = BIT(0);
inline static constexpr const uint32_t NVME_CSTS_CFS  = BIT(1);

struct ControllerInfo
{
    PH_UNUSED uint16_t vid;
    PH_UNUSED uint16_t ssvid;
    PH_UNUSED uint8_t  sn[20];
    PH_UNUSED uint8_t  mn[40];
    PH_UNUSED uint8_t  fr[8];
    PH_UNUSED uint8_t  rab;
    PH_UNUSED uint8_t  ieee[3];
    PH_UNUSED uint8_t  mic;
    PH_UNUSED uint8_t  mdts;
    PH_UNUSED uint16_t cntlid;
    PH_UNUSED uint32_t ver;
    PH_UNUSED uint8_t  reserved1[428];
    PH_UNUSED uint8_t  sqes;
    PH_UNUSED uint8_t  cqes;
    PH_UNUSED uint8_t  reserved2[2570];
};

std::atomic<uint32_t> NVMeController::controllerCount = 0;

uint32_t              queueSlots                      = 0;
uint32_t              doorbellStride                  = 0;
uint32_t              cacheBlockSize                  = 0;

#define PAGE_SIZE PhysicalMemoryManager::GetPageSize()

void NVMeController::Initialize(PCI::Address addr)
{
    uint64_t queueCount = CPU::cpus.GetSize();
    uint32_t irq        = PCI::GetInterruptLine(addr);

    PCI::EnableMemorySpace(addr);
    PCI::EnableBusMastering(addr);
    PCI::ReadBAR(addr, 0, bar0);
    size_t    bar1     = PCI::Read<dword>(addr, 0x14);

    uint32_t* bar0Addr = reinterpret_cast<uint32_t*>(bar0.address);
    bar0Addr = (uint32_t*)((size_t)(((uint64_t)bar0Addr & -8) | bar1 << 32)
                           + BootInfo::GetHHDMOffset());
    cr       = reinterpret_cast<ControllerRegister*>(bar0Addr);

    cr->cc &= ~NVME_CC_EN;
    while (cr->csts & NVME_CSTS_RDY) __asm__ volatile("nop");

    queueSlots     = std::min(cr->cap & 0xffff, (cr->cap >> 16) & 0xffff);
    doorbellStride = (cr->cap >> 32) & 0xf;

    volatile NVMeSubmission* submit = new volatile NVMeSubmission[queueSlots];
    volatile NVMeCompletion* completion
        = new volatile NVMeCompletion[queueSlots];
    uint32_t           qid = 0;
    volatile uint32_t* submitDoorbell
        = (uint32_t*)((size_t)cr + PAGE_SIZE
                      + (2 * qid * (4 << doorbellStride)));
    volatile uint32_t* completeDoorbell
        = (uint32_t*)((size_t)cr + PAGE_SIZE
                      + ((2 * qid + 1) * (4 << doorbellStride)));

    adminQueue.Initialize(submit, completion, submitDoorbell, completeDoorbell,
                          qid, 0, queueSlots);

    uint32_t aqa = queueSlots - 1;
    aqa |= aqa << 16;
    aqa |= aqa << 16;
    cr->aqa     = aqa;
    uint32_t cc = NVME_CC_IOSQES | NVME_CC_IOCQES | NVME_CC_EN;

    cr->asq     = (size_t)adminQueue.submit - BootInfo::GetHHDMOffset();
    cr->acq     = (size_t)adminQueue.completion - BootInfo::GetHHDMOffset();
    cr->cc      = cc;
    while (true)
    {
        uint32_t status = cr->csts;
        if (status & NVME_CSTS_RDY) break;
        else if (status & NVME_CSTS_CFS)
        {
            LogWarn("NVMe: Failed to CreateNode Admin Queues!");
            return;
        }
    }
    ControllerInfo* id     = new ControllerInfo;

    int             status = Identify(id);
    if (status != 0)
    {
        LogWarn("NVMe: Failed to identify NVMe device");
        return;
    }
    delete id;

    // TODO: Use MSI
    ioQueues = new NVMeQueue[queueCount];
    for (uint32_t i = 0; i < queueCount; i++)
    {
        volatile NVMeSubmission* ioSubmit
            = new volatile NVMeSubmission[queueSlots];
        volatile NVMeCompletion* ioComplete
            = new volatile NVMeCompletion[queueSlots];
        uint32_t           ioQID = i + 1;
        volatile uint32_t* ioSubmitDB
            = (uint32_t*)((size_t)cr + PAGE_SIZE
                          + (2 * ioQID * (4 << doorbellStride)));
        volatile uint32_t* ioCompleteDB
            = (uint32_t*)((size_t)cr + PAGE_SIZE
                          + ((2 * ioQID + 1) * (4 << doorbellStride)));
        LogTrace("Creating IO queues...");
        ioQueues[i].Initialize(ioSubmit, ioComplete, ioSubmitDB, ioCompleteDB,
                               ioQID, 0, queueSlots);
        {
            NVMeSubmission sub        = {};
            sub.createComplete.opcode = NVME_ADMIN_OPCODE_CREATE_CQ;
            sub.createComplete.prp1   = reinterpret_cast<uint64_t>(ioComplete)
                                    - BootInfo::GetHHDMOffset();
            sub.createComplete.cqid      = ioQID;
            sub.createComplete.qsize     = queueSlots - 1;
            sub.createComplete.cqFlags   = BIT(0);
            sub.createComplete.irqVector = 0;
            if (adminQueue.SubmitWait(&sub))
                LogError("NVMe: Failed to Create Completion Queue");
        }
        {
            NVMeSubmission sub      = {};
            sub.createSubmit.opcode = NVME_ADMIN_OPCODE_CREATE_SQ;
            sub.createSubmit.prp1   = reinterpret_cast<uint64_t>(ioSubmit)
                                  - BootInfo::GetHHDMOffset();
            sub.createSubmit.sqid    = ioQID;
            sub.createSubmit.qsize   = queueSlots - 1;
            sub.createSubmit.sqFlags = 1;
            sub.createSubmit.cqid    = ioQID;
            if (adminQueue.SubmitWait(&sub))
                LogError("NVMe: Failed to Create Submission Queue");
        }
    }

    uint8_t* buf = (uint8_t*)PhysicalMemoryManager::CallocatePages(10)
                 + BootInfo::GetHHDMOffset();
    DetectDevices();
    //    NVMeDiskDevice device(*this, 2);
    //    NVMeDiskDevice device2(*this, 3);
    //    device.Initialize();
    //    device2.Initialize();

    if (devices.size() >= 0)
    {
        //        LogInfo("namespaceID: %d", devices.front().namespaceID);
        //        devices.front().Read(buf, 0, 1);
    }
    //    device.Read(buf, 0, 1);
    //    LogInfo("Boot sig = %x", buf[510]);

    //    LogTrace("Found NVMe Controller!%d", bar0Addr[5]);
}
void NVMeController::Shutdown()
{
    // TODO: Shutdown
    NotImplemented();
}

int NVMeController::Identify(struct ControllerInfo* id)
{
    int            length        = sizeof(ControllerInfo);
    NVMeSubmission command       = {};
    command.identify.opcode      = NVME_ADMIN_OPCODE_IDENTIFY;
    command.identify.namespaceID = 0;
    command.identify.cns         = 1;
    command.identify.prp1        = (size_t)id - BootInfo::GetHHDMOffset();
    int offset                   = (size_t)id & (PAGE_SIZE - 1);
    length -= (PAGE_SIZE - offset);
    if (length <= 0) { command.identify.prp2 = (size_t)0; }
    else
    {
        size_t addr           = (size_t)id + (PAGE_SIZE - offset);
        command.identify.prp2 = (size_t)addr;
    }

    uint16_t status = adminQueue.SubmitWait(&command);
    if (status != 0) return -1;

    maxDataTransfer = ((id->mdts != 0) ? (id->mdts - 1) : 15);
    cacheBlockSize  = PAGE_SIZE * maxDataTransfer;
    return 0;
}
void NVMeController::DetectDevices()
{
    LogInfo("Detecting devices...");
    uint32_t* namespaces = new uint32_t[4096];
    for (uint32_t i = 0; i < 4096; i++) namespaces[i] = 0;
    {
        NVMeSubmission sub = {};
        uint16_t       status;
        sub.identify.opcode = NVME_ADMIN_OPCODE_IDENTIFY;
        sub.identify.prp1   = reinterpret_cast<uint64_t>(namespaces)
                          - BootInfo::GetHHDMOffset();
        sub.identify.cns = 0x02;
        status           = adminQueue.SubmitWait(&sub);
        if (status)
        {
            LogWarn("NVMe: Failed to detect namespaces!");
            return;
        }
    }

    for (uint32_t i = 0; i < 4096; i++)
    {
        // namespace with id 0 is controller,
        // and it is last element in namespaces array, so we just break
        if (namespaces[i] == 0) break;
        devices.push_back({*this, namespaces[i]});

        if (!devices.back().Initialize())
        {
            LogWarn("NVMe: Failed to initialize device!");
            devices.pop_back();
            return;
        }
    }
}
