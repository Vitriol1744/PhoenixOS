/*
 * Created by vitriol1744 on 19.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Common.hpp"

#include "BootInfo.hpp"
#include "Memory/PhysicalMemoryManager.hpp"

inline static constexpr const uint32_t NVME_ADMIN_OPCODE_CREATE_SQ = 0x01;
inline static constexpr const uint32_t NVME_ADMIN_OPCODE_CREATE_CQ = 0x05;
inline static constexpr const uint32_t NVME_ADMIN_OPCODE_IDENTIFY  = 0x06;

inline static constexpr const uint32_t NVME_IO_OPCODE_WRITE        = 0x01;
inline static constexpr const uint32_t NVME_IO_OPCODE_READ         = 0x02;

struct NVMeCommandIdentify
{
    uint8_t  opcode;
    uint8_t  flags;
    uint16_t commandID;
    uint32_t namespaceID;
    uint64_t reserved1[2];
    uint64_t prp1;
    uint64_t prp2;
    uint32_t cns;
    uint32_t reserved2[5];
};
struct NVMeCommandCreateSubmissionQueue
{
    uint8_t  opcode;
    uint8_t  flags;
    uint16_t commandID;
    uint32_t reserved1[5];
    uint64_t prp1;
    uint64_t reserved2;
    uint16_t sqid;
    uint16_t qsize;
    uint16_t sqFlags;
    uint16_t cqid;
    uint64_t reserved3[2];
};
struct NVMeCommandCreateCompletionQueue
{
    uint8_t  opcode;
    uint8_t  flags;
    uint16_t commandID;
    uint32_t reserved1[5];
    uint64_t prp1;
    uint64_t reserved2;
    uint16_t cqid;
    uint16_t qsize;
    uint16_t cqFlags;
    uint16_t irqVector;
    uint64_t reserved3[2];
};

struct NVMeCommandReadWrite
{
    uint8_t  opcode;
    uint8_t  flags;
    uint16_t commandID;
    uint32_t namespaceID;
    uint64_t reserved;
    uint64_t metadata;
    uint64_t prp1;
    uint64_t prp2;
    uint64_t slba;
    uint16_t length;
    uint16_t control;
    uint32_t dsmgmt;
    uint32_t reftag;
    uint16_t apptag;
    uint16_t appmask;
};
struct NVMeSubmission
{
    union
    {
        struct
        {
            uint8_t  opcode;
            uint8_t  flags;
            uint16_t commandID;
            uint32_t namespaceID;
            uint32_t cdw2[2];
            uint64_t metadata;
            uint64_t prp1;
            uint64_t prp2;
        };
        NVMeCommandIdentify              identify;
        NVMeCommandCreateSubmissionQueue createSubmit;
        NVMeCommandCreateCompletionQueue createComplete;
        NVMeCommandReadWrite             readWrite;
    };
};

struct NVMeCompletion
{
    uint32_t result;
    uint32_t reserved;
    uint16_t sqHead;
    uint16_t sqID;
    uint16_t commandID;
    uint16_t status;
};

class NVMeQueue
{
  public:
    void                     Initialize(volatile NVMeSubmission* submitQueue,
                                        volatile NVMeCompletion* completeQueue,
                                        volatile uint32_t*       submitDoorbell,
                                        volatile uint32_t* completeDoorbell, uint16_t qid,
                                        uint8_t irq, uint32_t depth);

    volatile NVMeSubmission* submit;
    volatile NVMeCompletion* completion;
    volatile uint32_t*       submitDoorbell;
    volatile uint32_t*       completeDoorbell;
    uint16_t                 cqVector;
    uint16_t                 sqHead;
    uint16_t                 tail;
    uint16_t                 previousTail = 0;
    uint32_t                 depth;
    uint16_t                 cqHead;
    uint8_t                  cqPhase;
    uint16_t                 id;
    uint32_t                 commandID;

    uint64_t*                prps;

    void                     Submit(NVMeSubmission* command);
    uint16_t                 SubmitWait(NVMeSubmission* command);
};