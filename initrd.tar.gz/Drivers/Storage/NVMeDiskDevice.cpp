/*
 * Created by vitriol1744 on 20.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "NVMeDiskDevice.hpp"

#include "Drivers/Storage/NVMeController.hpp"
#include "Drivers/Storage/NVMeQueue.hpp"

#define PAGE_SIZE 4096
bool NVMeDiskDevice::Initialize()
{
    Assert(controller != nullptr);
    NVMeIdentifyNamespace* info = new NVMeIdentifyNamespace;

    struct NVMeSubmission sub = {};
    sub.identify.opcode       = 0x06;
    sub.identify.namespaceID  = namespaceID;
    sub.identify.cns          = 0;
    sub.identify.prp1         = (size_t)info - BootInfo::GetHHDMOffset();

    uint16_t status               = controller->GetAdminQueue().SubmitWait(&sub);
    if (status != 0)
    {
        delete info;
        return false;
    }

    uint32_t formatted_lba = info->flbas & 0xf;
    blockSize               = 1 << ((info->lbaf[formatted_lba] >> 16) & 0xff);
    blockCount               = info->blockCount;
    LogInfo("LBA size: %d", blockSize);

    delete info;
    return true;
}

uint64_t        NVMeDiskDevice::ReadWrite(void* buffer, uint64_t lba, uint64_t count, bool write)
{
    Assert(blockSize != 0 && blockCount != 0);

    if (lba + count >= blockCount)
        lba -= (lba + count) - blockCount;
    int  pageOffset  = (size_t)buffer & (PAGE_SIZE - 1);
    bool usePRP2     = false;
    bool usePRPList = false;
    uint32_t commandID   = controller->GetIOQueue().commandID;
    if ((count * blockSize) > PAGE_SIZE)
    {
        if ((count  * blockSize) > (PAGE_SIZE * 2))
        {
            uint32_t prp_num = ((count - 1) * blockSize) / PAGE_SIZE;
            if (prp_num > controller->GetMaxDataTransfer())
            {
                LogError("NVMe: Max Data Transfer exceeded!");
                return -1;
            }
            for (uint32_t i = 0; i < prp_num; i++)
                controller->GetIOQueue().prps[i + commandID * controller->GetMaxDataTransfer()]
                    = ((size_t)((uint8_t*)buffer - BootInfo::GetHHDMOffset()
                                - pageOffset)
                       + PAGE_SIZE + i * PAGE_SIZE);
            usePRP2      = false;
            usePRPList = 1;
        }
        else usePRP2 = true;
    }
    struct NVMeSubmission command = {};
    command.readWrite.opcode      = write ? NVME_IO_OPCODE_WRITE : NVME_IO_OPCODE_READ;
    command.readWrite.flags       = 0;
    command.readWrite.namespaceID = namespaceID;
    command.readWrite.control     = 0;
    command.readWrite.dsmgmt      = 0;
    command.readWrite.reftag      = 0;
    command.readWrite.apptag      = 0;
    command.readWrite.appmask     = 0;
    command.readWrite.metadata    = 0;
    command.readWrite.slba        = lba;
    command.readWrite.length      = count - 1;
    if (usePRPList)
    {
        command.readWrite.prp1
            = (size_t)((size_t)buffer - BootInfo::GetHHDMOffset());
        command.readWrite.prp2
            = (size_t)(&controller->GetIOQueue().prps[commandID * controller->GetMaxDataTransfer()])
            - BootInfo::GetHHDMOffset();
    }
    else if (usePRP2)
    {
        command.readWrite.prp2
            = (size_t)((size_t)(buffer) + PAGE_SIZE - BootInfo::GetHHDMOffset());
    }
    else
        command.readWrite.prp1
            = (size_t)((size_t)buffer - BootInfo::GetHHDMOffset());
    uint16_t status = controller->GetIOQueue().SubmitWait(&command);
    if (status != 0)
    {
        LogError("NVMe: R/W operation failed with status %x", status);
        return -1;
    }
    return 0;
}