/*
 * Created by vitriol1744 on 12.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "PCI.hpp"

#include "ACPI.hpp"

struct MCFGTable
{
    SDTHeader header;
    uint64_t  reserved;
};

namespace PCI
{
    inline static constexpr const uint8_t  PCI_VENDOR_ID            = 0x00;
    inline static constexpr const uint8_t  PCI_DEVICE_ID            = 0x02;
    inline static constexpr const uint8_t  PCI_COMMAND              = 0x04;
    inline static constexpr const uint8_t  PCI_STATUS               = 0x06;
    inline static constexpr const uint8_t  PCI_REVISION_ID          = 0x08;
    inline static constexpr const uint8_t  PCI_PROG_IF              = 0x09;
    inline static constexpr const uint8_t  PCI_SUBCLASS             = 0x0a;
    inline static constexpr const uint8_t  PCI_CLASS_CODE           = 0x0b;
    inline static constexpr const uint8_t  PCI_CACHE_LINE_SIZE      = 0x0c;
    inline static constexpr const uint8_t  PCI_LATENCY_TIMER        = 0x0d;
    inline static constexpr const uint8_t  PCI_HEADER_TYPE          = 0x0e;
    inline static constexpr const uint8_t  PCI_BIST                 = 0x0f;
    inline static constexpr const uint8_t  PCI_BAR0                 = 0x10;
    inline static constexpr const uint8_t  PCI_BAR1                 = 0x14;
    inline static constexpr const uint8_t  PCI_BAR2                 = 0x18;
    inline static constexpr const uint8_t  PCI_BAR3                 = 0x1c;
    inline static constexpr const uint8_t  PCI_BAR4                 = 0x20;
    inline static constexpr const uint8_t  PCI_BAR5                 = 0x24;
    inline static constexpr const uint8_t  PCI_CARD_BUS_CIS_POINTER = 0x28;
    inline static constexpr const uint8_t  PCI_SUBSYSTEM_VENDOR_ID  = 0x2c;
    inline static constexpr const uint8_t  PCI_SUBSYSTEM_ID         = 0x2e;
    inline static constexpr const uint8_t  PCI_CAPABILITIES_POINTER = 0x34;
    inline static constexpr const uint8_t  PCI_INTERRUPT_LINE       = 0x3c;
    inline static constexpr const uint8_t  PCI_INTERRUPT_PIN        = 0x3d;
    inline static constexpr const uint8_t  PCI_MIN_GRANT            = 0x3e;
    inline static constexpr const uint8_t  PCI_MAX_LATENCY          = 0x3f;

    inline static constexpr const uint8_t  PCI_PRIMARY_BUS          = 0x18;
    inline static constexpr const uint8_t  PCI_SECONDARY_BUS        = 0x19;

    inline static constexpr const uint16_t PCI_INVALID              = 0xffff;

    static uint16_t                        GetDeviceType(Address addr)
    {
        return ((uint16_t)(Read<byte>(addr, PCI_CLASS_CODE)) << 8)
             | Read<byte>(addr, PCI_SUBCLASS);
    }
    static bool EnumerateBus(uint8_t bus, Enumerator& enumerator);
    static bool EnumerateFunctions(Address addr, Enumerator& enumerator)
    {
        if (Read<byte>(addr, PCI_HEADER_TYPE) == 0)
        {
            LogDebug("Interrupt Line: %x, Interrupt Pin: %x",
                     Read<byte>(addr, 0x3c), Read<byte>(addr, 0x3d));
        }

        if (enumerator(addr)) return true;
        uint16_t type = GetDeviceType(addr);
        if (type == ((0x06 << 8) | 0x04))
        {
            uint8_t secondaryBus = Read<byte>(addr, PCI_SECONDARY_BUS);
            if (EnumerateBus(secondaryBus, enumerator)) return true;
        }
        return false;
    }
    static bool EnumerateSlot(Address addr, Enumerator& enumerator)
    {
        addr.function = 0;
        if (Read<word>(addr, PCI_VENDOR_ID) == PCI_INVALID) return false;
        if ((Read<byte>(addr, PCI_HEADER_TYPE) & BIT(7)) == 0)
        {
            if (EnumerateFunctions(addr, enumerator)) return true;
        }
        else
        {
            for (uint8_t i = 0; i < 8; ++i)
            {
                addr.function = i;
                if (Read<word>(addr, 0) != PCI_INVALID)
                {
                    if (EnumerateFunctions(addr, enumerator)) return true;
                }
            }
        }

        return false;
    }
    static bool EnumerateBus(uint8_t bus, Enumerator& enumerator)
    {
        for (uint8_t slot = 0; slot < 32; ++slot)
        {
            if (EnumerateSlot({bus, slot, 0}, enumerator)) return true;
        }

        return false;
    }

    bool    Initialize()
    {
        bool status = true;
        Enumerate(
            [](Address addr) -> bool
            {
                LogWarn("Address: %#x:%#x:%#x, ID: %#x:%#x", addr.bus,
                        addr.slot, addr.function, GetVendorID(addr),
                        GetDeviceID(addr));
                return false;
            });
        LogTrace("PCI: Initialized");
        return status;
    }
    void EnableMemorySpace(Address address)
    {
        Write<word>(address, PCI_COMMAND,
                    Read<word>(address, PCI_COMMAND) | BIT(0));
    }
    void EnableBusMastering(Address address)
    {
        uint16_t command = Read<word>(address, PCI_COMMAND) | BIT(2) | BIT(0);
        Write<word>(address, PCI_COMMAND, command);
    }
    void DisableBusMastering(Address address)
    {
        uint16_t command = Read<word>(address, PCI_COMMAND) | BIT(0);
        command &= ~BIT(2);

        Write<word>(address, PCI_COMMAND, command);
    }
    void Enumerate(Enumerator enumerator)
    {
        if ((Read<byte>(Address(), PCI_HEADER_TYPE) & BIT(7)) == 0)
        {
            if (EnumerateBus(0, enumerator)) return;
        }
        else
        {
            for (uint8_t i = 0; i < 8; ++i)
            {
                if (Read<word>({0, 0, i}, 0) == PCI_INVALID) break;
                if (EnumerateBus(i, enumerator)) return;
            }
        }
    }

    uint32_t ReadBAR(Address address, int index, BAR& bar)
    {
        uint8_t  reg            = 4 * index + 0x10;
        uint32_t barOrigAddress = Read<dword>(address, reg);
        uint32_t barAddress     = barOrigAddress;
        if (barAddress == 0) return 0;
        bar.isMMIO       = ((barAddress & 1) == 0);
        bar.disableCache = false;
        if (bar.isMMIO && ((barAddress & (1 << 3)) != 0))
            bar.disableCache = true;
        bool is64Bit
            = (bar.isMMIO && ((((barAddress >> 1U) & 0b11U)) == 0b10U));
        if (is64Bit)
        {
            uint32_t barHighAddress = Read<dword>(address, reg + 4);
            if (barHighAddress != 0) return 0;
        }
        barAddress &= ~(bar.isMMIO ? (0b1111U) : (0b11U));
        Write<dword>(address, reg, 0xffffffff);
        uint32_t barSizeLow  = Read<dword>(address, reg);
        uint32_t barSizeHigh = 0xffffffff;
        Write<dword>(address, reg, barOrigAddress);
        if (is64Bit)
        {
            Write<dword>(address, reg + 4, 0xffffffff);
            barSizeHigh = Read<dword>(address, reg + 4);
            Write<dword>(address, reg + 4, 0);
        }
        uint64_t barSize
            = (((uint64_t)barSizeHigh) << 32ULL) | ((uint64_t)barSizeLow);
        barSize &= ~(bar.isMMIO ? (0b1111ULL) : (0b11ULL));
        barSize = ~barSize + 1ULL;
        if (barSize > 0xffffffff) return 0;
        bar.size    = (uint32_t)barSize;
        bar.address = barAddress;

        return barAddress;
    }
    uint16_t GetVendorID(Address address)
    {
        return Read<word>(address, PCI_VENDOR_ID);
    }
    uint16_t GetDeviceID(Address address)
    {
        return Read<word>(address, PCI_DEVICE_ID);
    }
    ClassCode GetClassCode(Address address)
    {
        return static_cast<ClassCode>(Read<byte>(address, PCI_CLASS_CODE));
    }
    Subclass GetSubclass(Address address)
    {
        return static_cast<Subclass>(Read<byte>(address, PCI_SUBCLASS));
    }
    ProgIF GetProgIF(Address address)
    {
        return static_cast<ProgIF>(Read<byte>(address, PCI_PROG_IF));
    }
    uint32_t GetInterruptLine(Address address)
    {
        return Read<byte>(address, PCI_INTERRUPT_LINE);
    }
} // namespace PCI