/*
 * Created by vitriol1744 on 12.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Common.hpp"

#include "Arch/Arch.hpp"

#include "Utility/Function.hpp"

#include <functional>

inline static constexpr const uint32_t PCI_CONFIG_ADDRESS = 0x0cf8;
inline static constexpr const uint32_t PCI_CONFIG_DATA    = 0x0cfc;

namespace PCI
{
    enum class ClassCode
    {
        eUnclassified                     = 0x00,
        eMassStorageController            = 0x01,
        eNetworkController                = 0x02,
        eDisplayController                = 0x03,
        eMultimediaController             = 0x04,
        eMemoryController                 = 0x05,
        eBridge                           = 0x06,
        eSimpleCommunicationController    = 0x07,
        eBaseSystemPeripheral             = 0x08,
        eInputDeviceController            = 0x09,
        eDockingStation                   = 0x0a,
        eProcessor                        = 0x0b,
        eSerialBusController              = 0x0c,
        eWirelessController               = 0x0d,
        eIntelligentController            = 0x0e,
        eSatelliteCommunicationController = 0x0f,
        eEncryptionController             = 0x10,
        eSignalProcessingController       = 0x11,
        eProcessingAccelerator            = 0x12,
        eNonEssentialInstrumentation      = 0x13,
        eCoprocessor                      = 0x40,
        eUnassigned                       = 0xff,
    };
    enum class Subclass
    {
        SATAController = 0x06,
        NVMController  = 0x08,
    };
    enum class ProgIF
    {
        AHCIv1     = 0x01,
        NVMExpress = 0x02,
    };

    struct Address
    {
        uint32_t bus      = 0;
        uint32_t slot     = 0;
        uint32_t function = 0;
    };
    struct BAR
    {
        uint32_t address;
        uint32_t size;

        bool     isMMIO;
        bool     disableCache;
    };
    // TODO: PCIe
    using Enumerator = std::function<bool(PCI::Address)>;

    bool           Initialize();
    void           EnableMemorySpace(PCI::Address address);
    void           EnableBusMastering(PCI::Address address);
    void           DisableBusMastering(PCI::Address address);
    void           Enumerate(Enumerator enumerator);

    uint32_t       ReadBAR(PCI::Address address, int index, PCI::BAR& bar);
    uint16_t       GetVendorID(PCI::Address address);
    uint16_t       GetDeviceID(PCI::Address address);
    PCI::ClassCode GetClassCode(PCI::Address address);
    PCI::Subclass  GetSubclass(PCI::Address address);
    PCI::ProgIF    GetProgIF(PCI::Address address);
    uint32_t       GetInterruptLine(PCI::Address address);

    template <typename T>
    T Read(Address addr, uint8_t offset)
    {
        uint32_t address = (uint32_t)0x80000000 | (addr.bus << 16)
                         | (addr.slot << 11) | (addr.function << 8)
                         | (offset & 0xfc);

        IO::Out<dword>(PCI_CONFIG_ADDRESS, address);
        return IO::In<T>(PCI_CONFIG_DATA + (offset & 3));
    }
    template <typename T>
    void Write(Address addr, uint8_t offset, T data)
    {
        uint32_t address = (uint32_t)0x80000000 | (addr.bus << 16)
                         | (addr.slot << 11) | (addr.function << 8)
                         | (offset & 0xfc);
        IO::Out<dword>(PCI_CONFIG_ADDRESS, address);
        IO::Out<T>(PCI_CONFIG_DATA + (offset & 3), data);
    }
}; // namespace PCI