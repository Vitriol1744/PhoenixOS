/*
 * Created by vitriol1744 on 22.11.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#include "ACPI.hpp"
#include "Common.hpp"

#include "Arch/x86/Drivers/Interrupts/PIC.hpp"
#include "Arch/x86/IDT.hpp"
#include "Arch/x86/IO.hpp"

#include "Drivers/Storage/NVMeController.hpp"

#include "Scheduler/Scheduler.hpp"

#include "Memory/PhysicalMemoryManager.hpp"
#include "Utility/Stacktrace.hpp"

#include "VirtualFileSystem/INode.hpp"
#include "VirtualFileSystem/Initrd/Initrd.hpp"
#include "VirtualFileSystem/TmpFs/TmpFs.hpp"
#include "VirtualFileSystem/TmpFs/TmpFsINode.hpp"
#include "VirtualFileSystem/VirtualFileSystem.hpp"

[[noreturn]]
static void kernelInitialize();
[[noreturn]]
static void thread2();

using ConstructorFunction = void (*)();

extern ConstructorFunction __init_array_start[];
extern ConstructorFunction __init_array_end[];

#define QemuExit()                                                             \
    {                                                                          \
        IO::Out<byte>(0x501, 0x31);                                            \
        IO::Out<word>(0xb004, 0x2000);                                         \
        IO::Out<word>(0x604, 0x2000);                                          \
        IO::Out<word>(0x4004, 0x3400);                                         \
    }
class SyscallHandler : public InterruptHandler
{
  public:
    static void PrintString(CPUContext* context)
    {
        LogError((const char*)context->rdi);
    }
    static void Invoke(CPUContext* context)
    {
        switch (context->rax)
        {
            case 0: return PrintString(context);
            default: panic("Unknown Syscall!");
        }
    }

  private:
    bool OnEndOfInterrupt() override { return true; }
    bool HandleInterrupt(CPUContext* ctx) override
    {
        Invoke(ctx);
        return true;
    }
};
SyscallHandler syscallHandler;

void           IterateDirectories(INode* node, int spaceCount = 0)
{
    char* spaces = new char[spaceCount + 1];
    memset(spaces, ' ', spaceCount);
    spaces[spaceCount] = 0;
    for (auto child : node->children)
    {
        LogInfo("%s-%s", spaces, child.second->name.data());
        if (child.second->GetType() == s_ifdir)
            IterateDirectories(child.second, spaceCount + 4);
    }
}

extern "C" __attribute__((noreturn)) void kernelStart()
{
    //    Terminal::ClearScreen(0x383c3c);
    // TODO: Enable Write-Combining
    LogTrace("Booting PhoenixOS...\n");
    LogInfo("Bootloader: %s, Version: %s\n", BootInfo::GetBootloaderName(),
            BootInfo::GetBootloaderVersion());
    LogInfo("HHDM Offset: %llx\n", BootInfo::GetHHDMOffset());
    LogInfo("Kernel Physical Address: %#p\nKernel Virtual Address: %#p\n ",
            BootInfo::GetKernelPhysicalAddress(),
            BootInfo::GetKernelVirtualAddress());
    LogInfo("Kernel Boot Time: %d\n", BootInfo::GetBootTime());

    GDT::Initialize();
    GDT::Load();
    PIC::Remap(0x20, 0x28);

    IDT::Initialize();
    IDT::Load();

    PhysicalMemoryManager::Initialize();

    for (ConstructorFunction* entry = __init_array_start;
         entry < __init_array_end; entry++)
    {
        ConstructorFunction constructor = *entry;
        constructor();
    }

    LogDebug("Used Memory: %ull", (PhysicalMemoryManager::GetUsedMemory()));
    size_t used = PhysicalMemoryManager::GetUsedMemory();
    VirtualMemoryManager::Initialize();
    used = PhysicalMemoryManager::GetUsedMemory() - used;
    LogDebug("Used Memory: %ull", (PhysicalMemoryManager::GetUsedMemory()));
    Stacktrace::Initialize();

    ACPI::Initialize();
    Assert(PCI::Initialize() == true);

    NVMeController nvmeController;

    CPU::InitializeBSP();

    CPU::StartUpAPs();
    TmpFs::Initialize();
    Assert(VirtualFileSystem::MountRoot("TmpFs"));
    //    Assert(VirtualFileSystem::Mount(nullptr, "", "/", "TmpFs"));
    Initrd::Initialize();

    INode* root = VirtualFileSystem::GetRootINode();
    Assert(root != nullptr);
    INode* n = VirtualFileSystem::CreateNode(
        root, "/VirtualFileSystem/init.cpp", s_ifdir);
    IterateDirectories(n->filesystem->root);
    halt();
    char* buffer = new char[256];
    memset(buffer, 'A', 255);
    buffer[255] = 0;
    n->Read(buffer, 0, 256);
    n->Write(buffer, 0, 256);
    char* b2 = new char[256];
    n->Read(b2, 0, 256);
    b2[255] = 0;
    LogInfo("Data: %s", b2);

    PCI::Enumerate(
        [&](PCI::Address addr) -> bool
        {
            if (PCI::GetClassCode(addr)
                    == PCI::ClassCode::eMassStorageController
                && PCI::GetSubclass(addr) == PCI::Subclass::NVMController)
                nvmeController.Initialize(addr);
            return false;
        });

    LogInfo("\n ____  _                      _       ___  ____  \n");
    LogInfo("|  _ \\| |__   ___   ___ _ __ (_)_  __/ _ \\/ ___| \n");
    LogInfo("| |_) | '_ \\ / _ \\ / _ \\ '_ \\| \\ \\/ / | |\\___ \\ \n");
    LogInfo("|  __/| | | | (_) |  __/ | | | |>  <| |_| |___)|\n");
    LogInfo("|_|   |_| |_|\\___/ \\___|_| |_|_/_/\\_\\___/|____/ \n");
    halt(nullptr);

    syscallHandler.SetInterruptNumber(0x80);
    IDT::RegisterInterruptHandler(&syscallHandler, DPL_RING3);

    Scheduler::Initialize();
    Scheduler::CreateKernelThread(
        Scheduler::GetKernelProcess(),
        reinterpret_cast<uintptr_t>(kernelInitialize));

    auto p = Scheduler::CreateProcess(VirtualMemoryManager::GetKernelPageMap());
    Scheduler::CreateKernelThread(p, (uintptr_t)thread2);

    Scheduler::Yield();

    QemuExit();
}

#if 0
    #define LogError(...)
    #define LogWarn(...)
#endif

[[noreturn]]
static void kernelInitialize()
{
    //    __asm__ volatile("cli");
    //    LogInfo("DOP");
    while (true)
    {
        const char* str = "World, World!";
        //        __asm__ volatile("mov $0, %%rax; mov %0, %%rdi; int $0x80"
        //                         :
        //                         : "r"(str)
        //                         : "rax", "rdi");
        __asm__ volatile("nop");
        LogWarn("Hello");
    }
}
[[noreturn]]
static void thread2()
{
    const char* str = "Hello, World!";
    __asm__ volatile("mov $0, %%rax; mov %0, %%rdi; int $0x80"
                     :
                     : "r"(nullptr)
                     : "rax", "rdi");

    while (true)
    {
        __asm__ volatile("mov $0, %%rax; mov %0, %%rdi; int $0x80"
                         :
                         : "r"(nullptr)
                         : "rax", "rdi");
        __asm__ volatile("nop");
    }
}
