#pragma once

#include <cstddef>
#include <cstdint>

#define SYMLOOP_MAX 40

using off_t     = long;

using dev_t     = unsigned long;
using ino_t     = unsigned long;

using nlink_t   = unsigned long;
using mode_t    = unsigned int;

using blksize_t = long;
using blkcnt_t  = long;

using uid_t     = unsigned int;
using gid_t     = unsigned int;

using time_t    = long;

enum types
{
    s_ifmt  = 0170000,
    s_iflnk = 0120000,
    s_ifreg = 0100000,
    s_ifdir = 0040000,
};
constexpr inline types mode2type(mode_t mode)
{
    return types(mode & s_ifmt ?: s_ifreg);
}

struct timespec
{
    time_t tv_sec;
    long   tv_nsec;

    constexpr timespec()
        : tv_sec(0)
        , tv_nsec(0)
    {
    }
    constexpr timespec(time_t s, long ns)
        : tv_sec(s)
        , tv_nsec(ns)
    {
    }
};

struct stat_t
{
    dev_t            st_dev;
    ino_t            st_ino;
    nlink_t          st_nlink;
    mode_t           st_mode;
    uid_t            st_uid;
    gid_t            st_gid;
    unsigned int     __unused0;
    dev_t            st_rdev;
    off_t            st_size;

    blksize_t        st_blksize;
    blkcnt_t         st_blocks;

    timespec         st_atim;
    timespec         st_mtim;
    timespec         st_ctim;

    constexpr types  type() { return types(this->st_mode & s_ifmt); }

    constexpr mode_t mode() { return this->st_mode & ~s_ifmt; }

    enum which
    {
        access = (1 << 0),
        modify = (1 << 1),
        status = (1 << 2)
    };

    enum accmode
    {
        read  = (1 << 0),
        write = (1 << 1),
    };
};
