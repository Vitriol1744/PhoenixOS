///*
// * Created by vitriol1744 on 22.11.2022.
// * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
// *
// * SPDX-License-Identifier: GPL-3
// */
// #include "KLibC.hpp"
//
// extern "C" size_t strlen(const char* str)
//{
//    size_t length = 0;
//    while (*str != '\0')
//    {
//        ++length;
//        ++str;
//    }
//    return length;
//}
// extern "C" int strcmp(const char* lhs, const char* rhs)
//{
//    while (*lhs != '\0')
//    {
//        if (*lhs != *rhs) return (*lhs - *rhs);
//        ++lhs;
//        ++rhs;
//    }
//    return 0;
//}
// extern "C" int strncmp(const char* lhs, const char* rhs, size_t bytes)
//{
//    while (*lhs != '\0' && bytes > 0)
//    {
//        if (*lhs != *rhs) return (*lhs - *rhs);
//
//        ++lhs;
//        ++rhs;
//        --bytes;
//    }
//    return 0;
//}
// extern "C" const char* strchr(const char* str, int ch)
//{
//    while (*str)
//    {
//        if (*str == ch) break;
//        str++;
//    }
//
//    return str;
//}
// extern "C" const char* strstr(const char* haystack, const char* needle)
//{
//    char nch;
//    char hch;
//
//    if ((nch = *needle++) != 0)
//    {
//        std::size_t len = strlen(needle);
//        do
//        {
//            do if ((hch = *haystack++) == 0)
//                    return nullptr;
//            while(hch != nch);
//        } while (strncmp(haystack, needle, len) != 0);
//        --haystack;
//    }
//
//    return haystack;
//}
//
// extern "C" int memcmp(const void* lhs, const void* rhs, std::size_t count)
//{
//    const char* s1 = (char*)lhs;
//    const char* s2 = (char*)rhs;
//
//    while (count-- > 0)
//        if (*s1++ != *s2++) return s1[-1] < s2[-1] ? -1 : 1;
//    return 0;
//}
// extern "C" void* memset(void* dest, char c, size_t bytes)
//{
//    char* d = reinterpret_cast<char*>(dest);
//    while (bytes > 0)
//    {
//        *d++ = c;
//        --bytes;
//    }
//    return dest;
//}
// extern "C" void* memcpy(void* dest, const void* src, size_t bytes)
//{
//    char* d = reinterpret_cast<char*>(dest);
//    char* s = reinterpret_cast<char*>(const_cast<void*>(src));
//
//    while (bytes > 0)
//    {
//        *d++ = *s++;
//        --bytes;
//    }
//    return dest;
//}
// extern "C" void* memmove(void* dest, const void* src, std::size_t count)
//{
//    if (dest < src) return memcpy(dest, src, count);
//
//    char* d = (char*)dest + count;
//    char* s = (char*)src + count;
//
//    while (count > 0)
//    {
//        *--d = *--s;
//        --count;
//    }
//
//    return dest;
//}