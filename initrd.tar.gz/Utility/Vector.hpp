/*
 * Created by vitriol1744 on 02.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include "Common.hpp"

#include "Scheduler/Spinlock.hpp"
#include "Utility/KLibC.hpp"

#include <new>
#include <utility>

void operator delete(void* ptr, size_t) noexcept;

template <typename T>
class Vector
{
  public:
    Vector() { Reallocate(2); }
    explicit Vector(size_t capacity)
        : capacity(capacity)
    {
        Reallocate(capacity);
    };
    ~Vector() { delete[] data; }

    void Reserve(size_t new_capacity)
    {
        if (new_capacity < size) return;

        T* new_data = new T[new_capacity];
        for (size_t i = 0; i < size; i++) new_data[i] = data[i];

        capacity = new_capacity;
        if (size > 0) delete[] data;
        data = new_data;
    }
    void Resize(size_t new_size)
    {
        Reserve(new_size);
        for (size_t i = size; i < capacity; i++) data[i] = {};
        size = new_size;
    }
    void PushBack(T& value)
    {
        if (size >= capacity) Reallocate(capacity ? capacity * 2 : 1);

        data[size] = value;
        ++size;
    }
    void PushBack(T&& value)
    {
        if (size >= capacity) Reallocate(capacity ? capacity * 2 : 1);

        data[size] = std::move(value);
        ++size;
    }
    void PopFront()
    {
        if (size > 0)
        {
            --size;
            data[0].~T();
            T* dest = &data[0];
            memcpy(dest, &data[1], size * sizeof(T));
        }
    }
    void PopBack()
    {
        if (size > 0)
        {
            --size;
            data[size].~T();
        }
    }

    const T& operator[](size_t index) const
    {
        if (index >= size) LogError("Vector: Index out of bounds!");
        return data[index];
    }
    T& operator[](size_t index)
    {
        if (index >= size) LogError("Vector: Index out of bounds!");
        return data[index];
    }

    inline size_t GetSize() const { return size; }
    inline size_t GetCapacity() const { return capacity; }

  private:
    T*     data     = nullptr;
    size_t size     = 0;
    size_t capacity = 0;

    void   Reallocate(size_t newCapacity)
    {
        T* newData
            = reinterpret_cast<T*>(::operator new(newCapacity * sizeof(T)));

        if (newCapacity < size) size = newCapacity;
        for (size_t i = 0; i < size; i++)
            new (&newData[i]) T(std::move(data[i]));

        for (size_t i = 0; i < size; i++) data[i].~T();

        ::operator delete(data, capacity * sizeof(T));
        data     = newData;
        capacity = newCapacity;
    }
};