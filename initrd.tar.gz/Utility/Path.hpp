#pragma once

#include "Utility/cwalk.h"
#include <mutex>
#include <string>
#include <vector>

struct PathSegment
{
    std::string_view segment;
    cwk_segment_type type;
    bool             isLast;
};

namespace Path
{
    inline bool IsAbsolute(std::string_view path)
    {
        return cwk_path_is_absolute(path.data());
    }
    inline std::vector<PathSegment> GetSegments(std::string_view path)
    {
        std::vector<PathSegment> ret;

        cwk_segment              seg;
        cwk_path_get_first_segment(path.data(), &seg);

        do {
            ret.push_back({std::string_view(seg.begin, seg.size),
                           cwk_path_get_segment_type(&seg), false});
        } while (cwk_path_get_next_segment(&seg));

        ret.back().isLast = true;

        return ret;
    }
} // namespace Path

using PathView = std::string_view;