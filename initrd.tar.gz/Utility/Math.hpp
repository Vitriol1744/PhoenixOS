/*
 * Created by vitriol1744 on 23.12.2022.
 * Copyright (c) 2022-2022, Szymon Zemke <Vitriol1744@gmail.com>
 *
 * SPDX-License-Identifier: GPL-3
 */
#pragma once

#include <cstdint>
#include <math.h>

namespace Math
{
    inline constexpr std::size_t AlignDown(std::size_t value,
                                           std::size_t alignment)
    {
        return (value & ~(alignment - 1));
    }
    inline constexpr std::size_t AlignUp(std::size_t value,
                                         std::size_t alignment)
    {
        return AlignDown(value + alignment - 1, alignment);
    }
    inline constexpr bool IsPowerOfTwo(std::size_t value)
    {
        return value != 0 && !(value & (value - 1));
    }
} // namespace Math